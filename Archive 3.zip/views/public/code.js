$('button').click(function(){
    $('.jumbo').toggle();
})  ;

$('button').click(function(){
    $('.middlepic').toggle();
})  ;

